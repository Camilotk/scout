.. _upgrade:

Upgrade guide
=============

The |version| release of |project| is compatible with the legacy
django-registration-redux (previously maintained by James Bennett)


Django version requirement
--------------------------

As of |version|, |project| requires Django 1.4 or newer;
older Django releases may work, but are officially unsupported.


Backwards-incompatible changes
------------------------------

None.
