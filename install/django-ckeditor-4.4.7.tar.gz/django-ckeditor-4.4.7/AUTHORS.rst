AUTHORS
=======


Created By
----------
#. `shaunsephton <http://github.com/shaunsephton>`_


Contributors
------------
#. `riklaunim <https://github.com/riklaunim>`_
#. `3point2 <https://github.com/3point2>`_
#. `buchuki <http://github.com/buchuki>`_
#. `chr15m <http://github.com/chr15m>`_
#. `hedleyroos <https://github.com/hedleyroos>`_
#. `jeffh <https://github.com/jeffh>`_
#. `lihan <https://github.com/lihan>`_
#. `loop0 <http://github.com/loop0>`_
#. `mwcz <https://github.com/mwcz>`_
#. `tomwys <https://github.com/tomwys>`_
#. `snbuback <https://github.com/snbuback>`_
#. And others `<https://github.com/**/django-ckeditor/graphs/contributors>`_
