CONTRIBUTORS
============

Project Lead
------------

* Douglas Miranda (@douglasmiranda / <douglasmirandasilva@gmail.com>)

Developers
----------

* (@ejnens)
* Stéphane Angel (@twidi)
* Gustavo Soares (@gustavosoares)
* @alrusdi
* Evan Borgstrom (@borgstrom)
* James Pic (@jpic)
* Silvano Nogueira (@snbuback)
* Emmanuelle Delescolle (@nanuxbe)