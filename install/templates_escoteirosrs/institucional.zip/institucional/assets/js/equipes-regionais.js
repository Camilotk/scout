(function($, window, document, undefined) {
	'use strict';

	var equipesRegionais = {

		init: function() {
			
		}
	};

	equipesRegionais.init();

}(jQuery, window, document));