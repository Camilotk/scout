(function($, window, document, undefined) {
	'use strict';

	var transparencia = {

		init: function() {
			
		}
	};

	transparencia.init();

}(jQuery, window, document));