(function($, window, document, undefined) {
	'use strict';

	var parceirosLista = {
		
		init: function() {
		}
	};

	parceirosLista.init();

}(jQuery, window, document));