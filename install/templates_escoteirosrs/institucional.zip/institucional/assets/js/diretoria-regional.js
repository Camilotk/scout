(function($, window, document, undefined) {
	'use strict';

	var diretoriaRegional = {

		init: function() {
			
		}
	};

	diretoriaRegional.init();

}(jQuery, window, document));