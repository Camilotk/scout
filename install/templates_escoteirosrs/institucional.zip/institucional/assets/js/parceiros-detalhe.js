(function($, window, document, undefined) {
	'use strict';

	var parceirosDetalhe = {
		
		init: function() {
			
		}
	};

	parceirosDetalhe.init();

}(jQuery, window, document));