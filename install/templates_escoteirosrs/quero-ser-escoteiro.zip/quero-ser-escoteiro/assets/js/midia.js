(function($, window, document, undefined) {
    'use strict';

    var midia = {
        infScroll: function() {
            $('.list-news').infinitescroll({
                navSelector: '.btn-load-midia',
                nextSelector: '.btn-load-midia',
                itemSelector: '.list-news li',
                dataType: 'html',
                animate: false,
                loading: {
                    img: 'assets/img/ajax-loader.gif',
                    finishedMsg: '<span class="txt-loader">Não há mais registros.</span>'
                },
                path: function() {
                    return 'midia-ajax.html';
                }
            }, function() {
                $('.btn-load-midia').fadeIn();
            });

            $(window).unbind('.infscr');

            $('.btn-load-midia').on('click', function() {
                $('.list-news').infinitescroll('retrieve');
                return false;
            });

        }
    };

    midia.infScroll();

}(jQuery, window, document));
