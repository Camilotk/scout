(function($, window, document, undefined) {
    'use strict';

    function noWatermark(value, element) {
        return (value !== element.title);
    }

    var midiaDetalhe = {
        galeria: function() {
            $('.fancybox').fancybox({
                padding: 0,
                margin: 120,
                openEffect: 'elastic',
                closeEffect: 'elastic',
                helpers: {
                    title: {
                        type: 'over'
                    }
                },
                afterLoad : function() {
                    this.title = $('.list-news li:nth-child('+ (this.index+1) +') a').attr('title') + ' <span>' + (this.index + 1) + '/' + this.group.length + '</span>';
                }
            });

            $('.fancybox').on('click', function() {
                if ($(window).width() < 700) {
                    return false;
                }
            });

        }
    };

    midiaDetalhe.galeria();

}(jQuery, window, document));
