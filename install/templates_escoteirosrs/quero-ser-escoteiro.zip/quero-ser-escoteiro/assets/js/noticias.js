(function($, window, document, undefined) {
    'use strict';

    var noticias = {
        infScroll: function() {
            $('.list-news').infinitescroll({
                navSelector: '.btn-load-noticia',
                nextSelector: '.btn-load-noticia',
                itemSelector: '.list-news li',
                dataType: 'html',
                animate: false,
                loading: {
                    img: 'assets/img/ajax-loader.gif',
                    finishedMsg: '<span class="txt-loader">Não há mais registros.</span>'
                },
                path: function() {
                    return 'noticias-ajax.html';
                }
            }, function() {
                $('.btn-load-noticia').fadeIn();
            });

            $(window).unbind('.infscr');

            $('.btn-load-noticia').on('click', function() {
                $('.list-news').infinitescroll('retrieve');
                return false;
            });

        }
    };

    noticias.infScroll();
    $('.watermark').watermark('Busca por palavra-chave','#999');

}(jQuery, window, document));
