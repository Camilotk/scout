(function($, window, document, undefined) {
    'use strict';

    var index = {

        slider: function() {

            $('.slider').cycle({
                fx: 'scrollHorz',
                speed: 600,
                slideResize: false,
                containerResize: false,
                fit: 1,
                timeout: 0,
                next: '.next',
                prev: '.prev',
                pager: '.pagination'
            });

        },

        news: function() {

            $('.list-news').cycle({
                fx: 'scrollHorz',
                speed: 600,
                slideResize: false,
                containerResize: false,
                fit: 1,
                timeout: 0,
                pager: '.pag-news'
            });

        },

        store: function() {

            $('.list-products').slick({
              infinite: false,
              slidesToShow: 4,
              slidesToScroll: 4
          });

            $('.slick-next, .slick-prev').addClass('btn ir');

        },

        sliderReset: function() {
            $('.slider').cycle('destroy');
            $('.products').cycle('destroy');
            index.slider();
        }

    };

    index.slider();
    index.news();

    if($(window).width() > 948){
        index.store();
    }

    $(window).resize(function() {
        if($(window).width() > 948){
            index.store();
        }else{
            index.sliderReset();
        }
    });

    $('.watermark').watermark('Busca por palavra-chave (Grupo, cidade, etc)','#999');


}(jQuery, window, document));
