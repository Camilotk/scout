(function($, window, document, undefined) {
	'use strict';

	function noWatermark(value, element) {
		return (value !== element.title);
	}

	var encontre = {
		formularioPesquisa: function() {

			$('.filtro select').selectPersonalizado();

			$('.txtPesquisar').watermark('Busca por palavra-chave (Grupo, cidade, etc)','#999999');

			$.validator.addMethod('nowatermark',
				function(value, element) {
					return noWatermark(value, element);
				});

			$('#formProcurar').validate({
				submitHandler: function() {
					// Busca itens.
				},
				rules: {
					txtPesquisar: {
						required: true,
						nowatermark: true
					},
					selCidade: {
						required: true,
						nowatermark: true
					},
				},
				messages: {
					txtPesquisar: {
						required: '*',
						nowatermark: '*'
					},
					selCidade: {
						required: '*',
						nowatermark: '*'
					},
				}
			});


			function verificaFiltro() {
				if ($('.filtro span').text() === 'Cidade') {
					$('.filtro').addClass('error');
				} else {
					$('.filtro').removeClass('error');
				}
			}

			$('#formProcurar').on('submit', function(e) {
				verificaFiltro(e);
			});

			$('.filtro select').on('change', function() {
				verificaFiltro();
			});

		},

        infScroll: function() {
            $('.box-grupos ul').infinitescroll({
                navSelector: '.btn-load-encontre',
                nextSelector: '.btn-load-encontre',
                itemSelector: '.box-grupos ul li',
                dataType: 'html',
                animate: false,
                loading: {
                    img: 'assets/img/ajax-loader.gif',
                    finishedMsg: '<span class="txt-loader">Não há mais registros.</span>'
                },
                path: function() {
                    return 'encontre-ajax.html';
                }
            }, function() {
                $('.btn-load-encontre').fadeIn();
            });

            $(window).unbind('.infscr');

            $('.btn-load-encontre').on('click', function() {
                $('.box-grupos ul').infinitescroll('retrieve');
                return false;
            });

        },

		init: function() {
            encontre.formularioPesquisa();
			encontre.infScroll();
		}
	};

	encontre.init();

}(jQuery, window, document));
