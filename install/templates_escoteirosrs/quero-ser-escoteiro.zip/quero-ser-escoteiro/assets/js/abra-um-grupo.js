(function($, window, document, undefined) {
	'use strict';

	var doacoes = {

		init: function() {
		}
	};

	doacoes.init();

}(jQuery, window, document));