(function($, window, document, undefined) {
    'use strict';

    function noWatermark(value, element) {
        return (value !== element.title);
    }

    var contato = {

        formulario: function() {
            $('.filtro select').selectPersonalizado();

            $('.txtFone').mask('(99) 9999-9999?9');

            $('.txtNome').watermark('Nome', '#000');
            $('.txtMail').watermark('E-mail', '#999');
            $('.txtFone').watermark('Telefone', '#999');
            $('.txtMsg').watermark('Mensagem', '#999');

            $('.contato-enviado').on('click', function() {
                $('.contato-enviado').fadeOut(350);
            });

            $.validator.addMethod('nowatermark',
                function(value, element) {
                    return noWatermark(value, element);
                });

            $('#formContact').validate({
                submitHandler: function() {
                    $('.contato-enviado').fadeIn(350);
                    $('#formContact input').each(function() {
                        $(this).val($(this).attr('title'));
                    });
                },
                rules: {
                    txtNome: {
                        required: true,
                        nowatermark: true
                    },
                    txtMail: {
                        required: true,
                        nowatermark: true,
                        email: true
                    },
                    txtFone: {
                        required: true,
                        nowatermark: true
                    },
                    selFalar: {
                        required: true,
                        nowatermark: true
                    },
                    txtMsg: {
                        required: true,
                        nowatermark: true
                    }
                },
                errorPlacement: function(elemtent) {
                    // errorPlacement
                }
            });


            function verificaFiltro() {
                if ($('.filtro span').text() === 'Com quem deseja falar?') {
                    $('.filtro').addClass('error');
                    e.preventDefault();
                } else {
                    $('.filtro').removeClass('error');
                }
            }

            $('#formContact').on('submit', function(e) {
                verificaFiltro(e);
            });

            $('.filtro select').on('change', function() {
                verificaFiltro();
            });

        },

        read: function(){
            $('.read').on('click',function(){
                $('.auditing').addClass('open');
            });
        },

        maps: function(){

            var map;

            var mapOptions = {
                zoom: 16,
                scrollwheel: false,
                panControl: false,
                zoomControl: true,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.SMALL
                },
                streetViewControl: false,
                scaleControl: true,
                center: new google.maps.LatLng(-30.030523,-51.20000),
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

            new google.maps.Marker({
                position: new google.maps.LatLng(-30.030840,-51.205421),
                map: map,
                title: 'Escoteiros do Brasil - Rio Grande do Sul',
                icon: 'assets/img/marker.png',
                cursor: 'default',
                draggable: false
            });

            var panoramaOptions = {
                position: new google.maps.LatLng(-30.030523,-51.206621),
                pov: {
                    heading: 13,
                    pitch: 8,
                    zoom: 1
                },
                linksControl: false,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.SMALL
                },
                panControl: false,
                enableCloseButton: false,
                visible: true
            };
            var panorama = new google.maps.StreetViewPanorama(document.getElementById('street-view'), panoramaOptions);

            $('.change-maps').click(function() {
                $('#street-view').removeClass('showing');
                $('#map-canvas').addClass('showing');
                $(this).removeClass('changer');
                $('.change-street').addClass('changer');
            });
            $('.change-street').click(function() {
                $('#map-canvas').removeClass('showing');
                $('#street-view').addClass('showing');
                $(this).removeClass('changer');
                $('.change-maps').addClass('changer');
            });

        },

        init: function() {
            contato.formulario();
            contato.read();

            if($(window).width() > 1280){
                contato.maps();
            }
        }

    };

    contato.init();

}(jQuery, window, document));
