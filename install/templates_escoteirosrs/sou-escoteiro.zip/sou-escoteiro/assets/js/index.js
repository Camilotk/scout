(function($, window, document, undefined) {
    'use strict';

    var index = {

        slider: function() {

            $('.slider').cycle({
                fx: 'scrollHorz',
                speed: 600,
                slideResize: false,
                containerResize: false,
                fit: 1,
                timeout: 0,
                next: '.next',
                prev: '.prev',
                pager: '.pagination'
            });

        },

        sliderReset: function() {
            $('.slider').cycle('destroy');
            index.slider();
        },

        nav: function() {

            $('.nav-patents a').on('click', function(e) {

                e.preventDefault();

                var href = $(this).attr('href');

                $('html, body').animate({
                    scrollTop: $(href).offset().top - $('#header').height()
                }, '500', 'swing');

            });
        }

    };

    index.slider();
    index.nav();

    $(window).resize(function() {
        if ($(window).width() > 948) {
            index.sliderReset();
        }
    });

}(jQuery, window, document));
