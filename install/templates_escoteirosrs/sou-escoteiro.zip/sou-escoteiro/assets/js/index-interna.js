(function($, window, document, undefined) {
    'use strict';

    var index = {

        slider: function() {

            $('.slider').cycle({
                fx: 'scrollHorz',
                speed: 600,
                slideResize: false,
                containerResize: false,
                fit: 1,
                timeout: 0,
                next: '.next',
                prev: '.prev',
                pager: '.pagination'
            });

        },

        news: function() {

            $('.list-news').cycle({
                fx: 'fade',
                speed: 600,
                slideResize: false,
                containerResize: false,
                fit: 1,
                timeout: 0,
                pager: '.pag-news'
            });

        },

        sliderReset: function() {
            $('.slider').cycle('destroy');
            index.slider();
        },

    };

    index.slider();
    index.news();

    $(window).resize(function() {
        if ($(window).width() > 948) {
            index.sliderReset();
        }
    });

}(jQuery, window, document));
