(function($, window, document, undefined) {
	'use strict';

	var mapaSite = {

		init: function() {

			
		}
	};

	mapaSite.init();

}(jQuery, window, document));